%% Load gnuplot 3D binary file to a cartesian matrix.
%%      z = rows(z) x columns(z) = length(x) x length(y)
%%
%% Gnuplot binary file data organization:
%% <N> <y1> .. <yN>  <x1> <row of z> <x2> <row of z> ...
%% where all numbers are floats.
%%
%% Author: Petr Mikulik
%% Version: June 2004 (docs improved)
%% Original version: February 2001
%% License: Public domain

function [x, y, z] = loadgpbin ( filename )
  % check input arguments
  if (nargin ~= 1)
    a=[	'\tUSAGE: [x, y, z] = loadgpbin( filename )\n', ...
	'\tWhere x, y are vectors and z is cartesian matrix length(x) x length(y)\n', ...
	'\tExample: [x,y,z]=loadgpbin(''a.gpbin''); imagesc(rot90(z));' ];
    fprintf(a);
    return
  end
  
  % working code
  f = fopen(sprintf(filename), 'rb');
  if (f < 0)
    error( sprintf('File %s does not exist', filename) );
  end
  [lenx, count] = fread(f, 1, 'float');
  lenx = round(lenx);
  if (lenx < 0 | lenx > 1024*1024)
    error(sprintf('I do not believe that there are really %i elements - wrong file format?', lenx));
  end
  [x, count] = fread(f, lenx, 'float');
  x = x';
  [z, count] = fread(f, inf, 'float');
  leny = length(z) / (lenx+1);
  if (leny ~= round(leny))
    warning('not integer number of y-columns - maybe garbage in the file')
    leny = ceil(leny);
  end
  z = reshape(z, (lenx+1), leny);
  y = z(1,:);	     % y is the first row in the matrix
  z = z(2:lenx+1,:); % remove the first row
  fclose (f);

% endfunction
