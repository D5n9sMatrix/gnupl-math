## EXPERIMENTAL CODE!!! by Dan Sebald. (Feb 21, 2005)
##
## This file is NOT part of the Octave distribution.
##
## This file is designed to work with an experimental version of
## Gnuplot having improved color plotting capabilities.  It remains
## compatible with the Octave version 2.9.4 "image.m" script if the
## Gnuplot version is less than 4.1.
##
## x and y are implemented in this script.
##
## =====================================================================
##
##
## Copyright (C) 1996, 1997 John W. Eaton
##
## Octave is free software; you can redistribute it and/or modify it
## under the terms of the GNU General Public License as published by
## the Free Software Foundation; either version 2, or (at your option)
## any later version.
##
## Octave is distributed in the hope that it will be useful, but
## WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
## General Public License for more details.
##
## You should have received a copy of the GNU General Public License
## along with Octave; see the file COPYING.  If not, write to the Free
## Software Foundation, 59 Temple Place - Suite 330, Boston, MA
## 02111-1307, USA.

## -*- texinfo -*-
## @deftypefn {Function File} {} __img__ (@var{x})
## @deftypefnx {Function File} {} __img__ (@var{x}, @var{y}, @var{A})
## Display a matrix as a color image.  The elements of @var{x} are indices
## into the current colormap and should have values between 1 and the
## length of the colormap.
##
## It first tries to use @code{gnuplot} if the version is high enough, then
## @code{display} from @code{ImageMagick}, then @code{xv} and then @code{xloadimage}.
##
## The axis values corresponding to the matrix elements are specified in
## @var{x} and @var{y}.
## @end deftypefn
## @seealso{imshow, imagesc, and colormap}

## Author: Tony Richardson <arichard@stark.cc.oh.us>
## Created: July 1994
## Adapted-By: jwe

function __img_gp__ (x, y, A, zoom)

  ## Use of zoom not encouraged.  Here only for compatibiliy for users
  ## who may not have the most recent version of gnuplot.  Remove zoom
  ## some time in the future, i.e., everything that says REMOVE IN FUTURE.

  if (nargin == 0)
    ## Load Bobbie Jo Richardson (Born 3/16/94)
    A = loadimage ("default.img");
    x = y = [];
    zoom = 1;  ## REMOVE IN FUTURE
  elseif (nargin == 1)
    A = x;
    x = y = [];
    zoom = 1;  ## REMOVE IN FUTURE
  elseif (nargin == 2)  ## REMOVE IN FUTURE
    A = x;
    x = y = [];
    zoom = 1;  ## REMOVE IN FUTURE
  elseif (nargin == 4)  ## REMOVE IN FUTURE
  elseif (nargin ~= 3)
    usage ("image (matrix) or image (x, y, matrix)");
  endif

  if (isempty(A))
    error("Image matrix is empty.");
  endif

  global __gnuplot_version__ = 0;

  ## Get gnuplot version if this is first time function is called.
  if (__gnuplot_version__ == 0)
    [output,status] = system([gnuplot_binary " --version"]);
    words = split(output, " ");
    if ( (size(words,1) >= 2) && isdigit(words(2,1)) )
      __gnuplot_version__ = sscanf(words(2,:), '%f', 1);
    else
      __gnuplot_version__ = -1;
    endif
    if (__gnuplot_version__ < 4.1)
      disp('Images can be displayed using Gnuplot version 4.1 or higher.');
    endif
  end

  if (__gnuplot_version__ >= 4.0)

    gset nokey;
    __current_color_map__ = colormap();
    palette_size = size(__current_color_map__,1);
    graw(sprintf('set palette positive color model RGB maxcolors %i\n', palette_size));
    if (palette_size <= 128)
      ## Break up command to avoid buffer overflow.
      gset palette file "-"
      for i = 1:palette_size
	graw(sprintf('%g %g %g %g\n',1e-3*round(1e3*[(i-1)/(palette_size-1) __current_color_map__(i,:)])));
      end
      graw("e\n");
    else
      # Let the file be deleted when Octave exits or `purge_tmp_files' is called.
      [fid, binary_file_name, msg] = mkstemp([P_tmpdir,'/gpimageXXXXXX'], 1);
      # text file version
      # fprintf(fid,'%g %g %g\n',__current_color_map__');
      # fclose(fid);
      # eval(sprintf('gset palette file "%s"',binary_file_name));
      # binary file version
      fwrite(fid, __current_color_map__', "float32", 0, "ieee-le");
      fclose(fid);
       eval(sprintf('gset palette file "%s" binary record=%d using 1:2:3',binary_file_name,palette_size));
    endif

    ## Use the newly added mode of "plot" called "with image".
    if (isempty(x))
      x = [1 size(A,2)];
      y = [1 size(A,1)];
    endif

    ## Force rectangular grid by using only end points of
    ## first row (column) if x (y) is a matrix or vector.
    if ((size(x,2)) > 1)
      x = x(1,:)';
    endif
    if (abs(x(end) - x(1)) < (10*eps))
      error("End points in x dimension must not be equal.");
    else
      x_dim = size(A,2);
      if (x_dim > 1)
	dx = (x(end)-x(1))/(x_dim-1);
      else
	dx = 1;
      endif
    endif
    if ((size(y,1)) > 1)
      y = y(:,1)';
    endif
    if (abs(y(end) - y(1)) < 10*eps)
      error("End points in y dimension must not be equal.");
    else
      y_dim = size(A,1);
      if (y_dim > 1)
	dy = (y(end)-y(1))/(y_dim-1);
      else
	dy = 1;
      endif
    endif

    eval (sprintf ('gset xrange [%g:%g]', x(1)-dx/2, x(end)+dx/2));
    eval (sprintf ('gset yrange [%g:%g]', y(1)-dy/2, y(end)+dy/2));
    gset autoscale fix; # "fix" is helpful for "a" hotkey
    gset tics out;

    GNUPLOT_HAS_BINARY_DATA_FILE_VIA_USING = 1;

    A = reshape(A,size(A,1)*size(A,2),1);
    if (GNUPLOT_HAS_BINARY_DATA_FILE_VIA_USING == 0)
      gset style data image; # Octave needs to have "image" added to its table.
      gplot A;
      gset style data points;
    else
      # Let the file be deleted when Octave exits or `purge_tmp_files' is called.
      [fid, binary_file_name, msg] = mkstemp([P_tmpdir,'/gpimageXXXXXX'], 1);
      ## Gnuplot reads binary files very quickly.  However, the 'fwrite' below
      ## is much slower than using the current 'gplot' command.
      fwrite(fid,A',"float",0,"ieee-le");
      fclose(fid);
      gnuplot_com = sprintf ('graw \"plot ''%s'' binary array=%dx%d scan=yx flipy origin=(%g,%g) dx=%g dy=%g endian=little using 1 with image\\n\"',binary_file_name,x_dim,y_dim,min(x(1),x(end)),min(y(1),y(end)),abs(dx),abs(dy));
      eval(gnuplot_com);
    endif
    ## Put back in default data mode.
    gset xrange [*:*];
    gset yrange [*:*];

  else  ## REMOVE IN FUTURE

    ppm_name = tmpnam ();

    saveimage (ppm_name, A, "ppm");

    ## Start the viewer.  Try xv, then xloadimage.

    xv = sprintf ('xv -expand %f %s', zoom, ppm_name);

    xloadimage = sprintf ('xloadimage -zoom %f %s', zoom*100, ppm_name);

    ## ImageMagick:
    im_display = sprintf ('display -geometry %f%% %s', zoom*100, ppm_name);

    rm = sprintf ('rm -f %s', ppm_name);

    ## Need to let the shell clean up the tmp file because we are putting
    ## the viewer in the background.

    system (sprintf ('( %s || %s || %s && %s ) > /dev/null 2>&1 &',
                     im_display, xv, xloadimage, rm));
  endif

endfunction
