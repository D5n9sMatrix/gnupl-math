## EXPERIMENTAL CODE!!! by Dan Sebald. (Feb 21, 2005)
##
## This file is NOT part of the Octave distribution.
##
##
## =====================================================================
##
##
## Copyright (C) 1996, 1997 John W. Eaton
##
## This file is part of Octave.
##
## Octave is free software; you can redistribute it and/or modify it
## under the terms of the GNU General Public License as published by
## the Free Software Foundation; either version 2, or (at your option)
## any later version.
##
## Octave is distributed in the hope that it will be useful, but
## WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
## General Public License for more details.
##
## You should have received a copy of the GNU General Public License
## along with Octave; see the file COPYING.  If not, write to the Free
## Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
## 02110-1301, USA.

## -*- texinfo -*-
## @deftypefn {Function File} {} imagesc (@var{A})
## @deftypefnx {Function File} {} imagesc (@var{x}, @var{y}, @var{A})
## @deftypefnx {Function File} {} imagesc (@dots{}, @var{zoom})
## @deftypefnx {Function File} {} imagesc (@dots{}, @var{limits})
## @deftypefnx {Function File} { @var{B} = } imagesc (@dots{})
## Display a scaled version of the matrix @var{A} as a color image.  The
## matrix is scaled so that its entries are indices into the current
## colormap.  The scaled matrix is returned.  If @var{zoom} is omitted, a
## comfortable size is chosen.  If @var{limits} = [@var{lo}, @var{hi}] are
## given, then that range maps into the full range of the colormap rather 
## than the minimum and maximum values of @var{A}.
##
## The axis values corresponding to the matrix elements are specified in
## @var{x} and @var{y}, either as pairs giving the minimum and maximum
## values for the respective axes, or as values for each row and column
## of the matrix @var{A}.  At present they are ignored.
## @end deftypefn
##
## @seealso{image and imshow}

## Author: Tony Richardson <arichard@stark.cc.oh.us>
## Created: July 1994
## Adapted-By: jwe

function ret = imagesc (x, y, A, zoom, limits)

  ## Use of zoom not encouraged.  Here only for compatibiliy for users
  ## who may not have the most recent version of gnuplot.  Remove zoom
  ## some time in the future, i.e., everything that says REMOVE IN FUTURE.

  if (nargin == 1)
    A = x;
    x = y = limits = [];
    zoom = 1;  ## REMOVE IN FUTURE
  elseif (nargin == 2)
    A = x;
    limits = y;
    x = y = [];
    zoom = 1;  ## REMOVE IN FUTURE
  elseif (nargin == 3)
    if (length(A) == 1)  ## REMOVE IN FUTURE
      A = x;
      limits = y;
      zoom = A;
      x = y = [];
    else
      limits = [];
      zoom = 1;  ## REMOVE IN FUTURE
    endif
  elseif (nargin == 4)
      limits = zoom;
  elseif (nargin == 5)  ## REMOVE IN FUTURE
  else % elseif (nargin ~= 4)
    usage ("B = imagesc ([x, y,] matrix [,limits])");
  endif

  ## use given limits or guess them from the matrix
  if (length (limits) == 0)
    maxval = max (A(:));
    minval = min (A(:));
  else
    minval = min(limits(:));
    maxval = max (limits(:));
    A(A < minval) = minval;
    A(A > maxval) = maxval;
  endif

  eval (sprintf ('gset cbrange [%f:%f]', minval, maxval));

  ## display or return the image
  if (nargout == 0)
    __img_gp__(x, y, A);
  else
    ## Rescale values to between 1 and length (colormap) inclusive.
    ## (Not exactly sure how much use this part of function gets, DJS)
    if (maxval == minval)
      ret = ones(size (A));
    else
      ret = round((A - minval) / (maxval - minval) * (rows(colormap) - 1)) + 1;
    end
  endif

endfunction
