The files in the associated archive file can replace the existing files in the
Octave tree. Simply put the files in a directory in the Octave path and create
symbolic links as:

image.m -> image_gp.m
imagesc.m -> imagesc_gp.m
imshow.m -> imshow_gp.m

No link is necessary for __img_gp__.m.

Octave will then use gnuplot to plot images if gnuplot's version is sufficient.

Dan Sebald, 15 Feb 2006


Changes:
    * 10.4.2006 -- fixed imagesc_gp.m for 4 input options
    *  8.4.2006 -- use binary palette files
